//= require_full_tree /asset-pipeline/test/absolute-path/full-tree
//= require_full_tree asset-pipeline/test/absolute-path/not-included