modules = {
    'plugin.platformCore.tools' {
        resource url:[plugin:'platformCore', dir:'css', file:'bootstrap.min.css']
        resource url:[plugin:'platformCore', dir:'js', file:'jquery.1.8.3.min.js']
        resource url:[plugin:'platformCore', dir:'js', file:'bootstrap.min.js']
        resource url:[plugin:'platformCore', dir:'css', file:'platformTools.css']
    }
}